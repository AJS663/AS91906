from django.shortcuts import render
from django.utils import timezone
from django.shortcuts import render, get_object_or_404, redirect
from .models import Book, BorrowRecord
from .forms import BookForm  # Assuming you've created forms for user input

def list_books(request):
    books = Book.objects.filter(available=True)
    return render(request, 'library/list_books.html', {'books': books})

def add_book(request):
    if request.method == "POST":
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('list_books')  # Redirect to the book list after adding
    else:
        form = BookForm()
    
    return render(request, 'library/add_book.html', {'form': form})

def borrow_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if book.available:
        BorrowRecord.objects.create(book=book, user=request.user.username)
        book.available = False
        book.save()
        return redirect('list_books')
    return render(request, 'library/error.html', {'message': 'Book is already borrowed'})

def return_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    borrow_record = BorrowRecord.objects.filter(book=book, return_date__isnull=True).first()
    
    if borrow_record:
        borrow_record.return_date = timezone.now()
        borrow_record.save()
        book.available = True
        book.save()
        return redirect('list_books')

    return render(request, 'library/error.html', {'message': 'Book was not borrowed'})

from django.urls import path
from . import views

urlpatterns = [
    path('', views.list_books, name='list_books'),
    path('add/', views.add_book, name='add_book'),
    path('borrow/<int:book_id>/', views.borrow_book, name='borrow_book'),
    path('return/<int:book_id>/', views.return_book, name='return_book'),
]
